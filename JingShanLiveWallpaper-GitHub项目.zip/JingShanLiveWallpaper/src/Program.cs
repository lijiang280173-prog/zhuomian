using System.Diagnostics;
using System.Runtime.InteropServices;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace JingShanLiveWallpaper;

internal static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.SetHighDpiMode(HighDpiMode.PerMonitorV2);
        using var app = new WallpaperApp();
        app.Run();
    }
}

internal sealed class WallpaperApp : IDisposable
{
    private readonly Form host;
    private readonly WebView2 webView;
    private readonly NotifyIcon tray;
    private readonly Timer watchdog;
    private IntPtr workerW;
    private bool attached;
    private bool exiting;

    public WallpaperApp()
    {
        host = new Form
        {
            FormBorderStyle = FormBorderStyle.None,
            ShowInTaskbar = false,
            StartPosition = FormStartPosition.Manual,
            Text = "静山动态壁纸",
            BackColor = Color.Black,
            Opacity = 1,
            WindowState = FormWindowState.Normal
        };
        host.SetStyle(ControlStyles.OptimizedDoubleBuffer, true);
        host.Load += (_, _) => InitializeWallpaper();
        host.FormClosing += (_, e) => { if (!exiting) e.Cancel = true; };

        webView = new WebView2 { Dock = DockStyle.Fill, Visible = false };
        host.Controls.Add(webView);

        var menu = new ContextMenuStrip();
        menu.Items.Add("重新连接桌面", null, (_, _) => AttachOrRetry());
        menu.Items.Add("暂停动画", null, (_, _) => TogglePause());
        menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("退出静山", null, (_, _) => Exit());
        tray = new NotifyIcon
        {
            Icon = SystemIcons.Application,
            Text = "静山 4K 动态壁纸",
            ContextMenuStrip = menu,
            Visible = true
        };
        tray.DoubleClick += (_, _) => AttachOrRetry();

        watchdog = new Timer { Interval = 3000 };
        watchdog.Tick += (_, _) =>
        {
            if (!exiting && (!attached || !IsWindow(workerW))) AttachOrRetry();
        };
    }

    public void Run()
    {
        host.Show();
        Application.Run();
    }

    private async void InitializeWallpaper()
    {
        host.Hide();
        AttachOrRetry();
        await InitializeWebViewAsync();
        watchdog.Start();
    }

    private async Task InitializeWebViewAsync()
    {
        try
        {
            var dataDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "JingShanLiveWallpaper", "WebView2");
            Directory.CreateDirectory(dataDir);
            var env = await CoreWebView2Environment.CreateAsync(null, dataDir);
            await webView.EnsureCoreWebView2Async(env);
            webView.CoreWebView2.Settings.AreDefaultContextMenusEnabled = false;
            webView.CoreWebView2.Settings.AreDevToolsEnabled = false;
            webView.CoreWebView2.Settings.IsZoomControlEnabled = false;
            var path = Path.Combine(AppContext.BaseDirectory, "wallpaper", "index.html");
            webView.CoreWebView2.Navigate(new Uri(path).AbsoluteUri);
            webView.Visible = true;
            AttachOrRetry();
        }
        catch (Exception ex)
        {
            File.WriteAllText(Path.Combine(Path.GetTempPath(), "JingShanWallpaper_error.txt"), ex.ToString());
            MessageBox.Show("静山动态壁纸启动失败。\n\n请确认 Windows 已安装 WebView2 Runtime。\n错误日志：%TEMP%\\JingShanWallpaper_error.txt", "静山", MessageBoxButtons.OK, MessageBoxIcon.Error);
            Exit();
        }
    }

    private void TogglePause()
    {
        if (webView.CoreWebView2 == null) return;
        webView.CoreWebView2.ExecuteScriptAsync("document.body.classList.toggle('paused');");
    }

    private void AttachOrRetry()
    {
        if (exiting) return;
        try
        {
            var worker = DesktopHost.FindWallpaperWorker();
            if (worker == IntPtr.Zero) return;
            workerW = worker;

            host.SuspendLayout();
            Native.SetParent(host.Handle, workerW);
            Native.SetWindowLongPtr(host.Handle, Native.GWL_STYLE, (IntPtr)(Native.WS_CHILD | Native.WS_VISIBLE | Native.WS_CLIPCHILDREN | Native.WS_CLIPSIBLINGS));
            Native.SetWindowLongPtr(host.Handle, Native.GWL_EXSTYLE, (IntPtr)Native.WS_EX_NOACTIVATE);
            Native.SetWindowPos(host.Handle, Native.HWND_BOTTOM, 0, 0, 0, 0, Native.SWP_NOMOVE | Native.SWP_NOSIZE | Native.SWP_NOACTIVATE | Native.SWP_FRAMECHANGED);
            ResizeToVirtualScreen();
            host.Show();
            host.SendToBack();
            host.ResumeLayout();
            attached = true;
        }
        catch (Exception ex)
        {
            attached = false;
            File.WriteAllText(Path.Combine(Path.GetTempPath(), "JingShanWallpaper_attach_error.txt"), ex.ToString());
        }
    }

    private void ResizeToVirtualScreen()
    {
        var x = SystemInformation.VirtualScreen.X;
        var y = SystemInformation.VirtualScreen.Y;
        var w = SystemInformation.VirtualScreen.Width;
        var h = SystemInformation.VirtualScreen.Height;
        Native.SetWindowPos(host.Handle, Native.HWND_BOTTOM, x, y, w, h, Native.SWP_NOACTIVATE | Native.SWP_SHOWWINDOW);
    }

    private void Exit()
    {
        if (exiting) return;
        exiting = true;
        watchdog.Stop();
        attached = false;
        try { Native.SetParent(host.Handle, IntPtr.Zero); } catch { }
        tray.Visible = false;
        Application.Exit();
    }

    public void Dispose()
    {
        exiting = true;
        watchdog.Dispose();
        tray.Dispose();
        webView.Dispose();
        host.Dispose();
    }
}

internal static class DesktopHost
{
    private const uint WM_SPAWN_WORKERW = 0x052C;

    public static IntPtr FindWallpaperWorker()
    {
        var progman = Native.FindWindow("Progman", null);
        if (progman == IntPtr.Zero) return IntPtr.Zero;

        // Windows 11 raised-desktop layout: ask Explorer to create the WorkerW layer.
        Native.SendMessageTimeout(progman, WM_SPAWN_WORKERW, (IntPtr)0xD, (IntPtr)0x1, Native.SMTO_NORMAL, 1000, out _);
        Native.SendMessageTimeout(progman, WM_SPAWN_WORKERW, IntPtr.Zero, IntPtr.Zero, Native.SMTO_NORMAL, 1000, out _);

        // Prefer a WorkerW directly under Progman when present (Win11 24H2+).
        var direct = Native.FindWindowEx(progman, IntPtr.Zero, "WorkerW", null);
        if (direct != IntPtr.Zero && Native.FindWindowEx(direct, IntPtr.Zero, "SHELLDLL_DefView", null) == IntPtr.Zero)
            return direct;

        // Classic layout: find the WorkerW sibling behind SHELLDLL_DefView.
        IntPtr result = IntPtr.Zero;
        Native.EnumWindows((top, lParam) =>
        {
            var shell = Native.FindWindowEx(top, IntPtr.Zero, "SHELLDLL_DefView", null);
            if (shell != IntPtr.Zero)
            {
                var w = Native.FindWindowEx(IntPtr.Zero, top, "WorkerW", null);
                if (w != IntPtr.Zero) result = w;
            }
            return result == IntPtr.Zero;
        }, IntPtr.Zero);
        return result;
    }
}

internal static class Native
{
    public const int GWL_STYLE = -16;
    public const int GWL_EXSTYLE = -20;
    public const long WS_CHILD = 0x40000000L;
    public const long WS_VISIBLE = 0x10000000L;
    public const long WS_CLIPCHILDREN = 0x02000000L;
    public const long WS_CLIPSIBLINGS = 0x04000000L;
    public const long WS_EX_NOACTIVATE = 0x08000000L;
    public const uint SWP_NOSIZE = 0x0001;
    public const uint SWP_NOMOVE = 0x0002;
    public const uint SWP_NOACTIVATE = 0x0010;
    public const uint SWP_SHOWWINDOW = 0x0040;
    public const uint SWP_FRAMECHANGED = 0x0020;
    public const uint SMTO_NORMAL = 0x0000;
    public static readonly IntPtr HWND_BOTTOM = new(-2);

    public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

    [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)] public static extern IntPtr FindWindow(string? lpClassName, string? lpWindowName);
    [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)] public static extern IntPtr FindWindowEx(IntPtr parentHandle, IntPtr childAfter, string? lpszClass, string? lpszWindow);
    [DllImport("user32.dll")] public static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);
    [DllImport("user32.dll")] public static extern IntPtr SetParent(IntPtr hWndChild, IntPtr hWndNewParent);
    [DllImport("user32.dll", EntryPoint = "SetWindowLongPtrW", SetLastError = true)] public static extern IntPtr SetWindowLongPtr(IntPtr hWnd, int nIndex, IntPtr dwNewLong);
    [DllImport("user32.dll", SetLastError = true)] public static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);
    [DllImport("user32.dll", SetLastError = true)] public static extern bool IsWindow(IntPtr hWnd);
    [DllImport("user32.dll", SetLastError = true)] public static extern IntPtr SendMessageTimeout(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam, uint flags, uint timeout, out IntPtr result);
}
