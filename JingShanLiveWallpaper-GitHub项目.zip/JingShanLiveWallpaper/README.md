# 静山 4K 原生动态桌面

这是一个 Windows 10/11 原生桌面动态壁纸项目：C#/.NET 8 + WinForms + WebView2 + WorkerW。

## 运行方式

1. Windows 11 通常已经有 WebView2 Runtime；如果启动失败，请安装 Microsoft Edge WebView2 Runtime。
2. 使用 GitHub Actions 编译：上传本项目到自己的 GitHub 仓库，Actions 会自动生成 Windows x64 发布包。
3. 发布包中双击 `JingShanLiveWallpaper.exe` 即可。
4. 系统托盘右键可以“重新连接桌面 / 暂停动画 / 退出静山”。

## 为什么这版不会再出现上一版那种全屏白屏思路

程序不会创建一个覆盖整个桌面的普通置顶窗口，而是寻找 Explorer 的 WorkerW 桌面层，并把壁纸窗口作为桌面子窗口挂进去。Windows 11 新版桌面层使用 Progman/WorkerW 的方式存在差异，因此代码同时处理新旧布局，并在 Explorer 重启后周期性重新寻找桌面层。

## GitHub Actions

`.github/workflows/build.yml` 会在 Windows runner 上构建 self-contained win-x64 单文件程序，并把发布包作为 artifact。
